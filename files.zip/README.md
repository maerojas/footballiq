# ⚽ FootballIQ — Instrucciones de uso

## Cómo usarla localmente

1. **Descargá** el archivo `index.html`
2. **Abrilo** directamente en tu navegador (doble click)
3. **Conseguí tu API key gratuita** en → https://www.football-data.org/client/register
   - Es gratis para siempre para Premier League, La Liga, Serie A, Bundesliga y Ligue 1
4. **Pegá la API key** en el panel izquierdo y hacé click en "Guardar y cargar datos"

## Funcionalidades

- ✅ Partidos en vivo, de hoy, próximos y finalizados
- ✅ Probabilidades calculadas con datos reales de tabla
- ✅ Tabla de posiciones con zonas (Champions, Europa, Descenso)
- ✅ Predictor con análisis profundo de Claude IA
- ✅ Forma reciente de cada equipo
- ✅ Estadísticas comparativas de temporada

## Para publicarla

### Opción A — GitHub Pages (gratis)
```
1. Creá un repositorio en github.com
2. Subí el index.html
3. Settings → Pages → Deploy from branch: main
4. Tu app estará en: https://tunombre.github.io/tu-repo
```

### Opción B — Netlify (gratis, más fácil)
```
1. Andá a netlify.com
2. Arrastrá la carpeta footballiq al panel de Netlify
3. Listo — URL automática en segundos
```

### Opción C — Vercel (gratis)
```
npx vercel footballiq/
```

## Ligas disponibles (plan gratuito football-data.org)

| Liga | Código |
|------|--------|
| Premier League | PL |
| La Liga | PD |
| Serie A | SA |
| Bundesliga | BL1 |
| Ligue 1 | FL1 |
| Champions League | CL |

## Nota sobre Liga Argentina y MLS

La API gratuita de football-data.org no incluye Liga Argentina ni MLS.
Para agregarlas necesitás:
- **API-Football** (api-sports.io) — 100 requests/día gratis, incluye Argentina y MLS
- O el plan Tier 1 de football-data.org (€49/mes)
